package com.aventstack.extentreports.reporter.klov.entity;

import lombok.ToString;

@ToString(callSuper = true)
public class KlovAuthor extends KlovAttribute {
}
