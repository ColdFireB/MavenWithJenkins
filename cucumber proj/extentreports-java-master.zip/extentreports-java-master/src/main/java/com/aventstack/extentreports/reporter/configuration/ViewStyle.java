package com.aventstack.extentreports.reporter.configuration;

public enum ViewStyle {
    DEFAULT, SPA
}