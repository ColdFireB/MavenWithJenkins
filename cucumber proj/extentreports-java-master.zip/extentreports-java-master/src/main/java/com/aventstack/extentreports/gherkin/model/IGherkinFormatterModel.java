package com.aventstack.extentreports.gherkin.model;

import java.io.Serializable;

public interface IGherkinFormatterModel extends Serializable {
}
