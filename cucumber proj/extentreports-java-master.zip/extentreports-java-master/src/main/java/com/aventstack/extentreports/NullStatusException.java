package com.aventstack.extentreports;

public class NullStatusException extends NullPointerException {
    private static final long serialVersionUID = 3331364668564936293L;
}
