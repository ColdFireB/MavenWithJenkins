package com.aventstack.extentreports.reporter.klov.entity;

public class KlovURI {
    public static final String PROJECT = "/api/projects";
    public static final String REPORT = "/api/reports";
}
