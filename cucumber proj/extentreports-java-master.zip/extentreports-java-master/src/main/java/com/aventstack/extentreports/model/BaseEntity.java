package com.aventstack.extentreports.model;

/**
 * Marker interface for entities
 */
public interface BaseEntity {
}
