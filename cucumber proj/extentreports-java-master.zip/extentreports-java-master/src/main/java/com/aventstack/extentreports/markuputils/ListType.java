package com.aventstack.extentreports.markuputils;

enum ListType {
    OL, UL
}
