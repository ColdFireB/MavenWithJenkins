package com.aventstack.extentreports.observer.entity;

public interface ObservedEntity {
}
