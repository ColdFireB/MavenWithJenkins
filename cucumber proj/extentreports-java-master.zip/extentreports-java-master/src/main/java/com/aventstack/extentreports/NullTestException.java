package com.aventstack.extentreports;

public class NullTestException extends NullPointerException {
    private static final long serialVersionUID = -2987170430890267069L;
}
