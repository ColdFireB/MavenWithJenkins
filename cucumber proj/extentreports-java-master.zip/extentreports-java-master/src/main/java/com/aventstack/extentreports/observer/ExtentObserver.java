package com.aventstack.extentreports.observer;

import com.aventstack.extentreports.observer.entity.ObservedEntity;

public interface ExtentObserver<T extends ObservedEntity> {
}
