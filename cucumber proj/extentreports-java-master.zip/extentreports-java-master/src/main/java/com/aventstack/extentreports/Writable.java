package com.aventstack.extentreports;

@FunctionalInterface
public interface Writable {
    void flush();
}
