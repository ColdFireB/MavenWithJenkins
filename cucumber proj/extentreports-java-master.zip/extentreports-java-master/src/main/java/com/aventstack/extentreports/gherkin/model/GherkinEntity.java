package com.aventstack.extentreports.gherkin.model;

import java.io.Serializable;

public abstract class GherkinEntity implements Serializable {
    private static final long serialVersionUID = 725203884274843593L;
}
