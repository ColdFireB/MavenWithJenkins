package com.aventstack.extentreports.model.service;

public interface EntityService {
}
