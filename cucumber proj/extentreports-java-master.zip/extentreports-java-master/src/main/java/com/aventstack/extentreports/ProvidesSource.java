package com.aventstack.extentreports;

public interface ProvidesSource {
	String getSource();
}
