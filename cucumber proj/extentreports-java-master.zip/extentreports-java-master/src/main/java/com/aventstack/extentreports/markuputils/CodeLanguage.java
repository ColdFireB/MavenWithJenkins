package com.aventstack.extentreports.markuputils;

/**
 * List of supported languages that will be prettified on output
 */
public enum CodeLanguage {
    XML, JSON
}
