package com.aventstack.extentreports.reporter;

/**
 * Mark interface
 */
public interface ExtentReporter {
}
