package com.aventstack.extentreports.reporter;

public abstract class AbstractReporter implements ExtentReporter {
}
