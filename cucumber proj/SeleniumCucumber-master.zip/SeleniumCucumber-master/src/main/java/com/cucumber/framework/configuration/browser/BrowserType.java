/**
 * rsr 
 *
 *Aug 6, 2016
 */
package com.cucumber.framework.configuration.browser;

/**
 * @author rsr
 *
 * Aug 6, 2016
 */
public enum BrowserType {
	Firefox,
	Chrome,
	Iexplorer,
	PhantomJs,
	HtmlUnitDriver

}
