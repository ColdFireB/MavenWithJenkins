/**
 * rsr 
 *
 *Aug 6, 2016
 */
package com.cucumber.framework.interfaces;

/**
 * @author rsr
 *
 * Aug 6, 2016
 */
public interface IwebComponent {

}
