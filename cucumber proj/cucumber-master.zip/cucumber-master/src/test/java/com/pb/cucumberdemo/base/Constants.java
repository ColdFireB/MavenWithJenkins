package com.pb.cucumberdemo.base;

public class Constants 
{
	public final static String CHROME_EXE = System.getProperty("user.dir")+"/exe/chromedriver.exe";
	public final static String ENV_FILE = System.getProperty("user.dir")+"/src/test/java/com/pb/cucumberdemo/base/environment.properties";

}
