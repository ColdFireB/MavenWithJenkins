package com.pb.cucumberdemo.utils;

public class ScreenshotsUtil {

}
