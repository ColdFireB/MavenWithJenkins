package com.cucumberFramework.enums;


public enum Browsers {
	
	CHROME,
	FIREFOX,
	IE

}
